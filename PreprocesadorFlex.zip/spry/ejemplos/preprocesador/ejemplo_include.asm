#include "../../preprocesador/constantes.h"

.QUAD VALOR_BASE
.QUAD PI
HLT
