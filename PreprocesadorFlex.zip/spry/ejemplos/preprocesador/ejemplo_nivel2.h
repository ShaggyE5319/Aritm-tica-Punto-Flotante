#define NIVEL_DOS 22
