#include "ejemplo_nivel1.h"

.QUAD NIVEL_UNO
.QUAD NIVEL_DOS
HLT
